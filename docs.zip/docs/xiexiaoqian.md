# This is Xie Xiaoqian
学了四年的数字媒体技术到头来发现啥都没学会的小five
改过自新重新做人ing

<img src="3.jpg" width="300">

[>>return](/)
