<!-- _coverpage.md -->

![logo](feng.jpg)

# welcome to our web~ <small>four vegetables</small>

> 一个设计小团队的日常。

- 向下滚动查看更多



[GitHub](https://github.com/NexMaker-Fab/2022zjudemini-team2)
[Get Started](#Hello!)