# This is Chen Zhiyi

一个工业设计专业的小美女

<img src="2.jpg" width="300">

[>>return](/)