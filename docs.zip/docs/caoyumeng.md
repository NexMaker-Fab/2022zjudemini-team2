# This is Cao Yumeng

底料：工业设计

特别添加：健身运动及摇滚属性

生产地：河北承德
> 样品简介仅供参考，详情以实物为主


<img src="1.jpg" width="300">

[>>return](/)